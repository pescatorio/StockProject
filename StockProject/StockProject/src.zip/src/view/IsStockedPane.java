package view;

import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EtchedBorder;

import DAO.MyOrderDAO;
import DAO.ProductDetailDAO;
import VO.MyOrderVO;
import VO.ProductVO;

public class IsStockedPane extends JPanel implements ActionListener{
	private JPanel jp[] = new JPanel[7];
	private JLabel jl[] = new JLabel[6];
	private JTextField tf[] = new JTextField[6];
	private JButton rsb;	//�ֹ��ϱ�
	private JButton okb;	//��ǰ��ȸ�ϱ�
	MyOrderVO mvo = new MyOrderVO();
	MyOrderDAO mdao = new MyOrderDAO();
	String[] caption = {"�ֹ����̵� : ","��ǰ���̵� : ","��������̵� : ","�ֹ��� : ","�ֹ��� : ","�԰�����(��[0]/��[1]) : "};
	
	public IsStockedPane(){
		setLayout(new GridLayout(8,1));
		EtchedBorder eb = new EtchedBorder();
		setBorder(eb);
		
		int size = caption.length;
		
		for(int i=0;i<size;i++){
			jl[i] = new JLabel(caption[i]);
			tf[i] = new JTextField(15);
			jp[i] = new JPanel();
			jp[i].add(jl[i]);
			jp[i].add(tf[i]);
			add(jp[i]);
			tf[i].setEditable(false);
				
		}
		tf[0].setEditable(true);
		jp[size] = new JPanel();
		okb = new JButton("�ֹ���ȸ");
		okb.addActionListener(this);
		rsb=new JButton("�԰�ó��");
		rsb.addActionListener(this);
		rsb.setEnabled(false);
		jp[size].add(okb);
		jp[size].add(rsb);
		add(jp[size]);
	}
	

	@Override
	public void actionPerformed(ActionEvent ae) {
		String ae_type = ae.getActionCommand();
		MyOrderVO mvo;
		ProductVO pvo;
		MyOrderDAO mdvo = new MyOrderDAO();
		ProductDetailDAO pdvo = new ProductDetailDAO();
		int tmpOid = Integer.parseInt((tf[0].getText()));	//order_id�� int������ ��ȯ�ϴ� �ӽú���
		if(ae_type.equals(okb.getText())){
			mvo = new MyOrderVO();
			try{
				if(tmpOid!=0){
					mvo = mdvo.getMyOrder(tmpOid);
				}
			}catch(Exception e){
				System.out.println("e=["+e+"]");
			}
			if(mvo!=null){
				tf[0].setText(mvo.getOrder_id()+"");
				tf[1].setText(mvo.getProuct_id()+"");
				tf[2].setText(mvo.getManufacturer_id()+"");
				tf[3].setText(mvo.getOrder_number()+"");
				tf[4].setText(mvo.getOrder_date());
				tf[5].setText(mvo.getIsStocked());
				tf[5].setEditable(true);
				rsb.setEnabled(true);
				
			}else{
				JOptionPane.showMessageDialog(this, "�ֹ����̵� �������� �ʽ��ϴ�.");
				int size = caption.length;
				for(int i=0;i<size;i++){
					tf[i].setText(null);
					tf[5].setEditable(false);
				}
			}
		}else if(ae_type.equals(rsb.getText())){
			mvo = new MyOrderVO();
			mdao= new MyOrderDAO();
			String tmpIsStocked = tf[5].getText();
			System.out.println(tmpIsStocked);
			if(tmpIsStocked.equals("0")||tmpIsStocked.equals("1")){
				int result= mdao.isStocked(tmpOid, tmpIsStocked);
				if(result>0){
					JOptionPane.showMessageDialog(this,"�԰�ó���� �Ϸ�Ǿ����ϴ�.");
				}else{
					JOptionPane.showMessageDialog(this,"�԰�ó����  �����Ͽ����ϴ�.");
				}
			}else{
				JOptionPane.showMessageDialog(this, "�԰���:0/ �԰���:1�� �Է����ּ���.");
			}
			
			int size = caption.length;
			for(int i =0; i<size;i++){
				if(tf[i]!=null)
				tf[i].setText(null);
				tf[5].setEditable(false);
			}
		}
	}
	
}